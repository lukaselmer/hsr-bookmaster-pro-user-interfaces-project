/*
 */
package com.jidesoft.plaf;

import javax.swing.plaf.ButtonUI;

/**
 * Pluggable look and feel interface for JButton.
 */
public abstract class JideButtonUI extends ButtonUI {
}

