/*
 * @(#)LookAndFeelExtension.java 4/8/2005
 *
 * Copyright 2002 - 2005 JIDE Software Inc. All rights reserved.
 */
package com.jidesoft.plaf;

import com.jidesoft.utils.ProductNames;

/**
 */
public interface LookAndFeelExtension extends ProductNames {
}
