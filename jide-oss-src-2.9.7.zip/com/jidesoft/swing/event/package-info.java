/**
 * The package contains events for components under com.jidesoft.swing package for JIDE Common Layer.
 */
package com.jidesoft.swing.event;