/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.extras;

import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

/**
 * An <code>Icon</code> implementation that paints two icons
 * as compound or overlaid icon using a specified alignment.<p>
 *
 * <strong>Note:</strong> This class is not yet part of the binary Validation
 * library; it comes with the Validation distributions as an extra.
 * <strong>The API is work in progress and may change without notice;
 * this class may even be completely removed from future distributions.</strong>
 * If you want to use this class, you may consider copying it into
 * your code base.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.13 $
 *
 * @see javax.swing.ImageIcon
 */
public final class CompoundIcon implements Icon {

    /**
     * Describes how to position the foreground icon to the background icon.
     */
    public enum Anchor {
        CENTER, NORTH, NORTHEAST, EAST, SOUTHEAST,
        SOUTH, SOUTHWEST, WEST, NORTHWEST }

    /**
     * Refers to the icon that will be painted in the background.
     */
    private final Icon backgroundIcon;

    /**
     * Refers to the icon that will be painted in the foreground.
     * This will often be a smaller overlay icon.
     */
    private final Icon foregroundIcon;

    private final int  height;
    private final int  width;
    private int xOffset;
    private int yOffset;


    // Instance Creation ******************************************************

    /**
     * Constructs a compound icon for the given foreground and background icons,
     * using a default anchor.
     *
     * @param backgroundIcon   the icon in the centered background
     * @param foregroundIcon   the icon that overlays the background icon
     */
    public CompoundIcon(Icon backgroundIcon, Icon foregroundIcon) {
        this(backgroundIcon, foregroundIcon, Anchor.SOUTHEAST);
    }

    /**
     * Constructs a compound icon for the given foreground and background icons,
     * using the specified anchor.
     *
     * @param backgroundIcon   the icon in the centered background
     * @param foregroundIcon   the icon that overlays the background icon
     * @param anchor           the position of the foreground icon relative
     *     to the background icon
     */
    public CompoundIcon(Icon backgroundIcon, Icon foregroundIcon, Anchor anchor) {
        this.backgroundIcon = backgroundIcon;
        this.foregroundIcon = foregroundIcon;
        height = Math.max(
                backgroundIcon.getIconHeight(),
                foregroundIcon.getIconHeight());
        width  = Math.max(
                backgroundIcon.getIconWidth(),
                foregroundIcon.getIconWidth());
        setAnchor(anchor);
    }


    // Implementing the Icon Interface ****************************************

    /**
     * Returns this icon's width, which is the maximum of
     * the widths of the background and foreground icons.
     *
     * @return an int specifying the fixed width of this icon.
     */
    public int getIconWidth() {
        return width;
    }

    /**
     * Returns this icon's height, which is the maximum of
     * the heights of the background and foreground icons.
     *
     * @return an int specifying the fixed height of this icon.
     */
    public int getIconHeight() {
        return height;
    }

    /**
     * Draws this icon at the specified location. First paints
     * the background icon at the specified location, then paints
     * the foreground icon using the offsets computed in #setAnchor.
     */
    public void paintIcon(Component c, Graphics g, int x, int y) {
        backgroundIcon.paintIcon(c, g, x, y);
        foregroundIcon.paintIcon(c, g, x + xOffset, y + yOffset);
    }


    // Helper Code ************************************************************

    private void setAnchor(Anchor anchor) {
        int xDiff = backgroundIcon.getIconWidth() - foregroundIcon.getIconWidth();
        int yDiff = backgroundIcon.getIconHeight() - foregroundIcon.getIconHeight();

        xOffset = ((anchor == Anchor.NORTHWEST)
                || (anchor == Anchor.WEST)
                || (anchor == Anchor.SOUTHWEST))
                ? 0
                : ((   (anchor == Anchor.NORTH)
                    || (anchor == Anchor.CENTER)
                    || (anchor == Anchor.SOUTH))
                    ? xDiff / 2
                    : xDiff);

        yOffset = ((anchor == Anchor.NORTHWEST)
                || (anchor == Anchor.NORTH)
                || (anchor == Anchor.NORTHEAST))
                ? 0
                : (((anchor == Anchor.WEST) || (anchor == Anchor.CENTER) || (anchor == Anchor.EAST))
                    ? yDiff / 2
                    : yDiff);
    }

}
