/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.basics;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.LayoutMap;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.ValidationResultModel;
import com.jgoodies.validation.tutorial.shared.Order;
import com.jgoodies.validation.tutorial.shared.OrderModel;
import com.jgoodies.validation.tutorial.util.ExampleComponentFactory;
import com.jgoodies.validation.tutorial.util.IconFeedbackPanel;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.view.ValidationComponentUtils;

/**
 * Demonstrates different styles how to indicate that a component
 * contains invalid data:
 * background changes if empty,
 * background reflects the severity,
 * overlaid icons reflect the severity.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.20 $
 */
public final class ComponentFeedbackExample extends TutorialApplication {

    private final OrderModel orderModel;

    private JTextField mandatoryOrderNoField;
    private JTextField mandatoryOrderDateField;
    private JTextField mandatoryDeliveryDateField;
    private JTextArea  mandatoryDeliveryNotesArea;
    private JComponent mandatoryPanel;

    private JTextField severityOrderNoField;
    private JTextField severityOrderDateField;
    private JTextField severityDeliveryDateField;
    private JTextArea  severityDeliveryNotesArea;
    private JComponent severityPanel;

    private JTextField iconOrderNoField;
    private JTextField iconOrderDateField;
    private JTextField iconDeliveryDateField;
    private JTextArea  iconDeliveryNotesArea;
    private JComponent iconOverlayPanel;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(ComponentFeedbackExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        LayoutMap.getRoot().columnPut("label", "[65dlu,pref]");
        JFrame frame = createFrame("Basics :: Component Feedback");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Instance Creation ******************************************************

    public ComponentFeedbackExample() {
        orderModel  = new OrderModel(new Order());
    }


    // Component Creation and Initialization **********************************

    private void initComponents() {
        mandatoryOrderNoField = ExampleComponentFactory.createTextField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_NO), false);
        mandatoryOrderDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_DATE),
                true);
        mandatoryDeliveryDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_DATE),
                true);
        mandatoryDeliveryNotesArea = ExampleComponentFactory.createTextArea(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_NOTES), false);

        severityOrderNoField = ExampleComponentFactory.createTextField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_NO), false);
        severityOrderDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_DATE));
        severityDeliveryDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_DATE),
                true);
        severityDeliveryNotesArea = ExampleComponentFactory.createTextArea(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_NOTES), false);

        iconOrderNoField = ExampleComponentFactory.createTextField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_NO), false);
        iconOrderDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_DATE));
        iconDeliveryDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_DATE),
                true);
        iconDeliveryNotesArea = ExampleComponentFactory.createTextArea(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_NOTES), false);
    }


    private void initComponentAnnotations() {
        ValidationComponentUtils.setMandatory(mandatoryOrderNoField, true);
        ValidationComponentUtils.setMessageKey(mandatoryOrderNoField, "Order.Order No");
        ValidationComponentUtils.setMandatory(mandatoryOrderDateField, true);
        ValidationComponentUtils.setMessageKey(mandatoryOrderDateField, "Order.Order Date");
        ValidationComponentUtils.setMessageKey(mandatoryDeliveryDateField, "Order.Delivery Date");
        ValidationComponentUtils.setMessageKey(mandatoryDeliveryNotesArea, "Order.Notes");

        ValidationComponentUtils.setMandatory(severityOrderNoField, true);
        ValidationComponentUtils.setMessageKey(severityOrderNoField, "Order.Order No");
        ValidationComponentUtils.setMandatory(severityOrderDateField, true);
        ValidationComponentUtils.setMessageKey(severityOrderDateField, "Order.Order Date");
        ValidationComponentUtils.setMessageKey(severityDeliveryDateField, "Order.Delivery Date");
        ValidationComponentUtils.setMessageKey(severityDeliveryNotesArea, "Order.Notes");

        ValidationComponentUtils.setMandatory(iconOrderNoField, true);
        ValidationComponentUtils.setMessageKey(iconOrderNoField, "Order.Order No");
        ValidationComponentUtils.setMandatory(iconOrderDateField, true);
        ValidationComponentUtils.setMessageKey(iconOrderDateField, "Order.Order Date");
        ValidationComponentUtils.setMessageKey(iconDeliveryDateField, "Order.Delivery Date");
        ValidationComponentUtils.setMessageKey(iconDeliveryNotesArea, "Order.Notes");
    }


    private void initEventHandling() {
        orderModel.getValidationResultModel().addPropertyChangeListener(
                ValidationResultModel.PROPERTYNAME_RESULT,
                new ValidationChangeHandler());
    }


    // Building ***************************************************************

    /**
     * Builds and returns the whole editor with 3 sections
     * for the different validation times.
     */
    public JComponent buildPanel() {
        initComponents();
        initComponentAnnotations();
        initEventHandling();

        mandatoryPanel   = buildMandatoryPanel();
        severityPanel    = buildSeverityPanel();
        iconOverlayPanel = buildIconOverlayPanel();

        FormLayout layout = new FormLayout(
                "fill:pref:grow",
                "p, $lgap, p, 17dlu, p, $lgap, p, 17dlu, p, $lgap, p");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.addSeparator("Background Indicates Blank Mandatory Fields", cc.xy(1,  1));
        builder.add(mandatoryPanel,                                         cc.xy(1,  3));
        builder.addSeparator("Background Indicates Invalid Input",          cc.xy(1,  5));
        builder.add(severityPanel,                                          cc.xy(1,  7));
        builder.addSeparator("Icons Indicate Invalid Input",                cc.xy(1,  9));
        builder.add(iconOverlayPanel,                                       cc.xy(1, 11));

        // Synchronize the presentation with the current validation state.
        // If you want to show no validation info before the user has typed
        // anything in the form, use the commented EMPTY result
        // instead of the model's validation result.
        updateComponentTreeMandatoryAndSeverity(
                orderModel.getValidationResultModel().getResult()
                // ValidationResult.EMPTY
        );

        return builder.getPanel();
    }


    private JComponent buildMandatoryPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu, 90dlu:grow",
                "p, $lgap, p, $lgap, p, $lgap, p");

        layout.setRowGroups(new int[][]{{1, 3, 5, 7}});
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No:",             cc.xy  (1, 1));
        builder.add(mandatoryOrderNoField,        cc.xyw (3, 1, 3));
        builder.addLabel("Order-/Delivery Date:", cc.xy  (1, 3));
        builder.add(mandatoryOrderDateField,      cc.xy  (3, 3));
        builder.add(mandatoryDeliveryDateField,   cc.xy  (5, 3));
        builder.add(new JScrollPane(mandatoryDeliveryNotesArea),
                                                  cc.xywh(3, 5, 4, 3));

        return builder.getPanel();
    }


    private JComponent buildSeverityPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu, 90dlu:grow",
                "p, $lgap, p, $lgap, p, $lgap, p");

        layout.setRowGroups(new int[][]{{1, 3, 5, 7}});
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No:",             cc.xy  (1, 1));
        builder.add(severityOrderNoField,         cc.xyw (3, 1, 3));
        builder.addLabel("Order-/Delivery Date:", cc.xy  (1, 3));
        builder.add(severityOrderDateField,       cc.xy  (3, 3));
        builder.add(severityDeliveryDateField,    cc.xy  (5, 3));
        builder.add(new JScrollPane(severityDeliveryNotesArea),
                                                  cc.xywh(3, 5, 4, 3));

        return builder.getPanel();
    }


    private JComponent buildIconOverlayPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu, 90dlu:grow",
                "p, $lgap, p, $lgap, p, $lgap, p, 4px"); // extra bottom space for icons

        layout.setRowGroups(new int[][]{{1, 3, 5, 7}});
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No:",             cc.xy  (1, 1));
        builder.add(iconOrderNoField,             cc.xyw (3, 1, 3));
        builder.addLabel("Order-/Delivery Date:", cc.xy  (1, 3));
        builder.add(iconOrderDateField,           cc.xy  (3, 3));
        builder.add(iconDeliveryDateField,        cc.xy  (5, 3));
        builder.addLabel("Notes:",                cc.xy  (1, 5));
        builder.add(new JScrollPane(iconDeliveryNotesArea),
                                                  cc.xywh(3, 5, 4, 3));

        return new IconFeedbackPanel(
                orderModel.getValidationResultModel(),
                builder.getPanel()
                );
    }


    // Event Handling *********************************************************

    private void updateComponentTreeMandatoryAndSeverity(ValidationResult result) {
        ValidationComponentUtils.updateComponentTreeMandatoryAndBlankBackground(
                mandatoryPanel);
        ValidationComponentUtils.updateComponentTreeSeverityBackground(
                severityPanel,
                result);
    }


    /**
     * Updates the component background in the mandatory panel and the
     * validation background in the severity panel. Invoked whenever
     * the observed validation result changes.
     */
    private final class ValidationChangeHandler implements PropertyChangeListener {

        public void propertyChange(PropertyChangeEvent evt) {
            updateComponentTreeMandatoryAndSeverity(
                    (ValidationResult) evt.getNewValue());
        }
    }


}
