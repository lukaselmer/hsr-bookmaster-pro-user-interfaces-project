/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.basics;

import java.awt.Component;
import java.awt.KeyboardFocusManager;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;

import com.jgoodies.binding.value.ValueHolder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.tutorial.util.ExampleComponentFactory;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.view.ValidationComponentUtils;
import com.jgoodies.validation.view.ValidationResultViewFactory;

/**
 * Demonstrates a style how to provide input hints,
 * so that users can avoid entering invalid data.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.15 $
 */
public final class InfoOnFocusExample extends TutorialApplication {

    private JLabel infoLabel;
    private JTextArea infoArea;
    private JComponent infoAreaPane;

    private JTextField orderNoField;
    private JTextField orderDateField;
    private JTextField deliveryDateField;
    private JTextArea  deliveryNotesArea;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(InfoOnFocusExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Basics :: Hints on Focus");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Component Creation and Initialization **********************************

    /**
     *  Creates and initializes the UI components.
     */
    private void initComponents() {
        orderNoField      = new JTextField();
        orderDateField    = ExampleComponentFactory.createDateField(new ValueHolder());
        deliveryDateField = ExampleComponentFactory.createDateField(new ValueHolder());
        deliveryNotesArea = new JTextArea();
    }


    private void initComponentAnnotations() {
        ValidationComponentUtils.setInputHint(orderNoField, "Mandatory, length in [5, 10]");
        ValidationComponentUtils.setInputHint(orderDateField, "Mandatory, before delivery date");
        ValidationComponentUtils.setInputHint(deliveryDateField, "After delivery date");
        ValidationComponentUtils.setInputHint(deliveryNotesArea, "Length <= 30");
    }


    private void initEventHandling() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager()
                .addPropertyChangeListener(new FocusChangeHandler());
    }


    // Building ***************************************************************

    /**
     * Builds and returns the whole editor.
     */
    public JComponent buildPanel() {
        initComponents();
        initComponentAnnotations();
        initEventHandling();

        FormLayout layout = new FormLayout(
                "fill:default:grow",
                "[14dlu,pref], 6dlu, pref, $lgap, pref");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();

        CellConstraints cc = new CellConstraints();
        builder.add(buildInfoAreaPane(), cc.xy(1, 1));
        builder.addSeparator("Order",    cc.xy(1, 3));
        builder.add(buildEditorPanel(),  cc.xy(1, 5));
        return builder.getPanel();
    }

    private JComponent buildEditorPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu, 90dlu:grow",
                "p, $lgap, p, $lgap, p, $lgap, p, 2px"); // extra bottom space for icons
        layout.setRowGroups(new int[][]{{1, 3, 5, 7}});

        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No:",             cc.xy  (1, 1));
        builder.add(orderNoField,                 cc.xyw (3, 1, 3));
        builder.addLabel("Order-/Delivery Date:", cc.xy  (1, 3));
        builder.add(orderDateField,               cc.xy  (3, 3));
        builder.add(deliveryDateField,            cc.xy  (5, 3));
        builder.addLabel("Notes:",                cc.xy  (1, 5));
        builder.add(new JScrollPane(deliveryNotesArea),
                                                  cc.xywh(3, 5, 4, 3));
        return builder.getPanel();
    }


    private JComponent buildInfoAreaPane() {
        infoLabel = new JLabel(ValidationResultViewFactory.getInfoIcon());
        infoArea = new JTextArea(1, 38);
        infoArea.setEditable(false);
        infoArea.setOpaque(false);

        FormLayout layout = new FormLayout(
                "pref, $lcgap, default",
                "pref");
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();
        builder.add(infoLabel, cc.xy(1, 1));
        builder.add(infoArea,  cc.xy(3, 1));

        infoAreaPane = builder.getPanel();
        infoAreaPane.setVisible(false);
        return infoAreaPane;
    }


    // Validation Handler *****************************************************

    /**
     * Displays an input hint for components that get the focus permanently.
     */
    private final class FocusChangeHandler implements PropertyChangeListener {

        public void propertyChange(PropertyChangeEvent evt) {
            String propertyName = evt.getPropertyName();
            if (!"permanentFocusOwner".equals(propertyName))
                return;

            Component focusOwner = KeyboardFocusManager
                    .getCurrentKeyboardFocusManager().getFocusOwner();

            String focusHint = focusOwner instanceof JComponent
                    ? (String) ValidationComponentUtils
                            .getInputHint((JComponent) focusOwner)
                    : null;

            infoArea.setText(focusHint);
            infoAreaPane.setVisible(focusHint != null);
        }
    }

}
