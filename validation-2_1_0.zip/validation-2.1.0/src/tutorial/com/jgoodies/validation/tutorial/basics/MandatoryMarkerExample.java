/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.basics;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.view.ValidationComponentUtils;

/**
 * Demonstrates different styles how to mark mandatory fields.
 * The fields in this demo are not bound and not validated.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.13 $
 */
public final class MandatoryMarkerExample extends TutorialApplication {

    private JLabel orderNoLabel;
    private JLabel orderDateLabel;

    private JTextField backgroundOrderNoField;
    private JTextField backgroundOrderDateField;
    private JTextField backgroundDeliveryDateField;

    private JTextField borderOrderNoField;
    private JTextField borderOrderDateField;
    private JTextField borderDeliveryDateField;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(MandatoryMarkerExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Basics :: Mandatory Marker");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Component Creation and Initialization **********************************

    private void initComponents() {
        orderNoLabel   = createMandatoryLabel("Order No:");
        orderDateLabel = createMandatoryLabel("Order-");

        backgroundOrderNoField      = new JTextField();
        backgroundOrderDateField    = new JTextField();
        backgroundDeliveryDateField = new JTextField();

        borderOrderNoField = new JTextField();
        borderOrderDateField = new JTextField();
        borderDeliveryDateField = new JTextField();
    }

    private void initComponentAnnotations() {
        ValidationComponentUtils.setMandatory(backgroundOrderNoField, true);
        ValidationComponentUtils.setMandatory(backgroundOrderDateField, true);

        ValidationComponentUtils.setMandatory(borderOrderNoField, true);
        ValidationComponentUtils.setMandatory(borderOrderDateField, true);
    }


    // Building ***************************************************************

    /**
     * Builds and returns the whole editor with 3 sections
     * for the different validation times.
     */
    public JComponent buildPanel() {
        initComponents();
        initComponentAnnotations();

        FormLayout layout = new FormLayout(
                "fill:pref:grow",
                "p, $lgap, p, 17dlu, p, $lgap, p, 17dlu, p, $lgap, p, 17dlu, p, $lgap, p");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.addSeparator("Label with *",         cc.xy(1,  1));
        builder.add(buildLabelWithStarPanel(),       cc.xy(1,  3));
        builder.addSeparator("Label Foreground",     cc.xy(1,  5));
        builder.add(buildLabelForegroundPanel(),     cc.xy(1,  7));
        builder.addSeparator("Component Background", cc.xy(1,  9));
        builder.add(buildComponentBackgroundPanel(), cc.xy(1, 11));
        builder.addSeparator("Component Border",     cc.xy(1, 13));
        builder.add(buildComponentBorderPanel(),     cc.xy(1, 15));
        return builder.getPanel();
    }


    private JComponent buildLabelWithStarPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu",
                "p, $lgap, p");

        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No*:",             cc.xy (1, 1));
        builder.add(new JTextField(),              cc.xyw(3, 1, 3));
        builder.addLabel("Order-*/Delivery Date:", cc.xy (1, 3));
        builder.add(new JTextField(),              cc.xy (3, 3));
        builder.add(new JTextField(),              cc.xy (5, 3));
        return builder.getPanel();
    }


    private JComponent buildLabelForegroundPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu",
                "p, $lgap, p");

        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.add(orderNoLabel,                 cc.xy (1, 1));
        builder.add(new JTextField(),             cc.xyw(3, 1, 3));
        builder.add(buildDateLabelBar(),          cc.xy (1, 3));
        builder.add(new JTextField(),             cc.xy (3, 3));
        builder.add(new JTextField(),             cc.xy (5, 3));
        return builder.getPanel();
    }

    private JComponent buildDateLabelBar() {
        FormLayout layout = new FormLayout("pref, pref", "pref");
        PanelBuilder builder = new PanelBuilder(layout);
        builder.add(orderDateLabel);
        builder.nextColumn();
        builder.addLabel("/Delivery Date:");
        return builder.getPanel();
    }


    private JComponent buildComponentBackgroundPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu",
                "p, $lgap, p");

        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No:",              cc.xy (1, 1));
        builder.add(backgroundOrderNoField,        cc.xyw(3, 1, 3));
        builder.addLabel("Order-/Delivery Date:",  cc.xy (1, 3));
        builder.add(backgroundOrderDateField,      cc.xy (3, 3));
        builder.add(backgroundDeliveryDateField,   cc.xy (5, 3));

        ValidationComponentUtils.updateComponentTreeMandatoryBackground(
                builder.getPanel());

        return builder.getPanel();
    }


    private JComponent buildComponentBorderPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 44dlu, 2dlu, 44dlu",
                "p, $lgap, p");

        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No:",              cc.xy (1, 1));
        builder.add(borderOrderNoField,            cc.xyw(3, 1, 3));
        builder.addLabel("Order-/Delivery Date:",  cc.xy (1, 3));
        builder.add(borderOrderDateField,          cc.xy (3, 3));
        builder.add(borderDeliveryDateField,       cc.xy (5, 3));

        ValidationComponentUtils.updateComponentTreeMandatoryBorder(
                builder.getPanel());

        return builder.getPanel();
    }


    // Helper Code ************************************************************

    private static JLabel createMandatoryLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(ValidationComponentUtils.getMandatoryForeground());
        return label;
    }


}
