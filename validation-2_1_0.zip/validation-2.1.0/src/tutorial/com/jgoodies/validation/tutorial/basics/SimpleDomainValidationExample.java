/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.basics;

import java.awt.event.ActionEvent;
import java.text.DateFormat;
import java.util.Date;

import javax.swing.*;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.tutorial.shared.Order;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.tutorial.util.TutorialUtils;
import com.jgoodies.validation.tutorial.validator.OrderValidator;

/**
 * A simple validation example that uses a "copying" binding,
 * not the JGoodies Binding. The domain Order object is validated
 * using an OrderValidator. On OK pressed, a modal dialog shows
 * the validation errors and warnings - if any.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.12 $
 */
public final class SimpleDomainValidationExample extends TutorialApplication {

    private Order order;

    private JTextField orderNoField;
    private JFormattedTextField orderDateField;
    private JFormattedTextField deliveryDateField;
    private JTextArea  deliveryNotesArea;
    private JButton    okButton;
    private JButton    closeButton;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(SimpleDomainValidationExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Basic :: Simple Domain Validation");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Initialization *********************************************************

    private void init() {
        order = new Order();
    }


    // Component Creation and Initialization **********************************

    /**
     *  Creates and initializes the UI components.
     */
    protected void initComponents() {
        orderNoField      = new JTextField();
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        orderDateField    = new JFormattedTextField(dateFormat);
        deliveryDateField = new JFormattedTextField(dateFormat);
        deliveryNotesArea = new JTextArea();

        okButton = new JButton(new OKAction());
        closeButton = new JButton(TutorialUtils.getCloseAction());
    }


    // Building ***************************************************************

    /**
     * Builds the whole editor.
     *
     * @return the editor panel with a report area at the bottom
     */
    public JComponent buildPanel() {
        init();
        initComponents();
        updateView();
        return buildPanelWithReportInBottom();
    }


    /**
     * Builds the whole editor.
     *
     * @return the editor panel with a report area at the bottom
     */
    private JComponent buildPanelWithReportInBottom() {
        FormLayout layout = new FormLayout(
                "fill:default:grow",
                "pref, $ugap:grow, pref");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();

        CellConstraints cc = new CellConstraints();
        builder.add(buildEditorPanel(), cc.xy(1, 1));
        builder.add(buildButtonBar(),   cc.xy(1, 3));
        return builder.getPanel();
    }


    private JComponent buildEditorPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 40dlu, 2dlu, 40dlu, 82dlu:grow");

        DefaultFormBuilder builder = new DefaultFormBuilder(layout);
        builder.setRowGroupingEnabled(true);

        CellConstraints cc = new CellConstraints();

        builder.appendSeparator("Order");
        builder.append("Order No:",             orderNoField, 3);
        builder.append("Order-/Delivery Date:", orderDateField, deliveryDateField);       builder.nextLine();

        builder.append("Notes:");
        builder.appendRow("17dlu"); // Assumes line is 14, gap is 3
        builder.add(new JScrollPane(deliveryNotesArea),
                    cc.xywh(builder.getColumn(), builder.getRow(), 4, 2));

        // Append a small gap at the bottom so the overlay icon is visible
        builder.nextLine();
        builder.appendRow("2px");

        return builder.getPanel();
    }


    private JComponent buildButtonBar() {
        return ButtonBarFactory.buildOKCancelBar(okButton, closeButton);
    }


    // Synchronizing Model and View *******************************************

    private void updateView() {
        orderNoField.setText(getOrder().getOrderNo());
        orderDateField.setValue(getOrder().getOrderDate());
        deliveryDateField.setValue(getOrder().getDeliveryDate());
        deliveryNotesArea.setText(getOrder().getDeliveryNotes());
    }


    private void updateModel() {
        getOrder().setOrderNo(orderNoField.getText());
        getOrder().setOrderDate((Date) orderDateField.getValue());
        getOrder().setDeliveryDate((Date) deliveryDateField.getValue());
        getOrder().setDeliveryNotes(deliveryNotesArea.getText());
    }


    private Order getOrder() {
        return order;
    }


    // Event Handling *********************************************************

    /**
     * Validates the GUI state and updates the model only,
     * if the GUI state has no errors (it may have warnings).
     */
    private final class OKAction extends AbstractAction {

        OKAction() {
            super("OK");
        }

        public void actionPerformed(ActionEvent e) {
            updateModel();
            ValidationResult validationResult = new OrderValidator().validate(order);
            if (validationResult.hasErrors()) {
                TutorialUtils.showValidationMessage(
                        e,
                        "To save the order, fix the following errors:",
                        validationResult);
                return;
            }
            if (validationResult.hasWarnings()) {
                TutorialUtils.showValidationMessage(
                        e,
                        "Note: some order fields are invalid.",
                        validationResult);
            }
            System.out.println("Data saved");
        }

    }


}
