/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.basics;

import java.awt.event.ActionEvent;

import javax.swing.*;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.Severity;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.ValidationResultModel;
import com.jgoodies.validation.message.SimpleValidationMessage;
import com.jgoodies.validation.tutorial.util.IconFeedbackPanel;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.util.DefaultValidationResultModel;
import com.jgoodies.validation.view.ValidationComponentUtils;
import com.jgoodies.validation.view.ValidationResultViewFactory;

/**
 * Demonstrates how to associate validation messages with UI components.
 * Provides buttons to set a couple of valid and invalid results.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.8 $
 */
public final class ValidationMessageKeysExample extends TutorialApplication {

    private static final Object KEY1 = "key1";
    private static final Object KEY2 = "key2";

    private final ValidationResultModel resultModel;

    private JComponent noKeyField;
    private JComponent key1Field;
    private JComponent key2Field;
    private JComponent key1Key2Field;

    private JButton validButton;
    private JButton errorsButton;
    private JButton warningsButton;
    private JButton mixedButton;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(ValidationMessageKeysExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Basics :: Validation Message Keys");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Instance Creation ******************************************************

    public ValidationMessageKeysExample() {
        resultModel = new DefaultValidationResultModel();
        resultModel.setResult(createResult1());
    }


    // Component Creation and Initialization **********************************

    private void initComponents() {
        noKeyField    = new JTextField();
        key1Field     = new JTextField();
        key2Field     = new JTextField();
        key1Key2Field = new JTextField();

        validButton    = new JButton(new SetResultAction("Empty", ValidationResult.EMPTY));
        errorsButton   = new JButton(new SetResultAction("1 Only", createResult1()));
        warningsButton = new JButton(new SetResultAction("2 Only", createResult2()));
        mixedButton    = new JButton(new SetResultAction("1 & 2", createResult3()));
    }


    private void initComponentAnnotations() {
        ValidationComponentUtils.setMessageKey(key1Field, KEY1);
        ValidationComponentUtils.setMessageKey(key2Field, KEY2);
        ValidationComponentUtils.setMessageKeys(key1Key2Field, new Object[]{KEY1, KEY2});
    }


    // Building ***************************************************************

    /**
     * Builds and returns the whole editor.
     */
    public JComponent buildPanel() {
        initComponents();
        initComponentAnnotations();

        FormLayout layout = new FormLayout(
                "$label, $lcgap, 160dlu:grow",
                "p, $lgap, p, $lgap, p, $lgap, p, $lgap, p, 9dlu:grow, p");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.addLabel("No key:",               cc.xy (1,  1));
        builder.add(noKeyField,                   cc.xy (3,  1));
        builder.addLabel("Key1:",                 cc.xy (1,  3));
        builder.add(key1Field,                    cc.xy (3,  3));
        builder.addLabel("Key2:",                 cc.xy (1,  5));
        builder.add(key2Field,                    cc.xy (3,  5));
        builder.addLabel("Key1, Key2:",           cc.xy (1,  7));
        builder.add(key1Key2Field,                cc.xy (3,  7));


        builder.addLabel("List:",                 cc.xy (1,  9, "l, t"));
        builder.add(ValidationResultViewFactory.
            createReportList(resultModel),        cc.xy (3,  9));

        builder.add(buildButtonBar(),             cc.xyw(1, 11, 3));

        return new IconFeedbackPanel(
                resultModel,
                builder.getPanel());
    }



    private JComponent buildButtonBar() {
        return ButtonBarFactory.buildRightAlignedBar(
                validButton, errorsButton, warningsButton, mixedButton);
    }


    // Helper Code ************************************************************

    /**
     * Sets the given ValidationResult as the resultModel's result
     * when performed. Used to create the 4 command buttons.
     */
    private final class SetResultAction extends AbstractAction {

        private final ValidationResult result;

        SetResultAction(String name, ValidationResult result) {
            super(name);
            this.result = result;
        }

        public void actionPerformed(ActionEvent e) {
            resultModel.setResult(result);
        }

    }


    private static ValidationResult createResult1() {
        ValidationResult result = new ValidationResult();
        result.add(new SimpleValidationMessage("Message1 for key1", Severity.ERROR,   KEY1));
        result.add(new SimpleValidationMessage("Message2 for key1", Severity.WARNING, KEY1));
        return result;
    }


    private static ValidationResult createResult2() {
        ValidationResult result = new ValidationResult();
        result.add(new SimpleValidationMessage("Message1 for key2", Severity.ERROR,   KEY2));
        result.add(new SimpleValidationMessage("Message2 for key2", Severity.WARNING, KEY2));
        return result;
    }


    private static ValidationResult createResult3() {
        ValidationResult result = new ValidationResult();
        result.add(new SimpleValidationMessage("Message1 for key1", Severity.ERROR,   KEY1));
        result.add(new SimpleValidationMessage("Message2 for key1", Severity.WARNING, KEY1));
        result.add(new SimpleValidationMessage("Message1 for key2", Severity.ERROR,   KEY2));
        result.add(new SimpleValidationMessage("Message2 for key2", Severity.WARNING, KEY2));
        return result;
    }


}
