/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.formatted;

import java.text.DateFormat;
import java.text.Format;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.text.DateFormatter;
import javax.swing.text.DefaultFormatter;
import javax.swing.text.DefaultFormatterFactory;

import com.jgoodies.binding.value.ValueHolder;
import com.jgoodies.binding.value.ValueModel;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.formatter.EmptyDateFormatter;
import com.jgoodies.validation.formatter.RelativeDateFormatter;
import com.jgoodies.validation.tutorial.formatted.format.DisplayFormat;
import com.jgoodies.validation.tutorial.formatted.format.RelativeDateFormat;
import com.jgoodies.validation.tutorial.util.ExampleComponentFactory;
import com.jgoodies.validation.tutorial.util.MyFocusTraversalPolicy;
import com.jgoodies.validation.tutorial.util.TutorialApplication;

/**
 * Demonstrates different configurations of {@code JFormattedTextField}
 * to display and edit numbers. Shows <ul>
 * <li>how to use a custom DateFormat
 * <li>how to use a custom DateFormatter
 * <li>how to use a custom FormatterFactory
 * <li>how to reset a date to {@code null}
 * <li>how to map the empty string to a special date
 * <li>how to commit values on valid texts
 * </ul><p>
 *
 * To look under the hood of this component, this class exposes
 * the bound properties <em>text</em>, <em>value</em> and <em>editValid</em>.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.23 $
 *
 * @see     JFormattedTextField
 * @see     JFormattedTextField.AbstractFormatter
 */
public final class DateExample extends TutorialApplication {


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(DateExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Formatted :: Dates");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Building ***************************************************************

    /**
     * Builds and returns a panel with a header row and the sample rows.
     *
     * @return the example panel with a header and the sample rows
     */
    public JComponent buildPanel() {
        FormLayout layout = new FormLayout(
                "$label, $lcgap, 45dlu, 1dlu, pref, 4dlu, pref, 0:grow");

        DefaultFormBuilder builder = new DefaultFormBuilder(layout);
        builder.setDefaultDialogBorder();
        builder.getPanel().setFocusTraversalPolicy(
                MyFocusTraversalPolicy.INSTANCE);

        Utils.appendTitleRow(builder, "Description");
        List<JFormattedTextField> fields = appendDemoRows(builder);

        String validText = DateFormat.getDateInstance().format(
                new GregorianCalendar(67, 11, 5).getTime());
        String invalidText = "aa" + validText;
        Utils.appendButtonBar(builder, fields, validText, invalidText);
        return builder.getPanel();
    }


    /**
     * Appends the demo rows to the given builder and returns the List of
     * formatted text fields.
     *
     * @param builder  the builder used to add components to
     * @return the List of formatted text fields
     */
    private List<JFormattedTextField> appendDemoRows(DefaultFormBuilder builder) {
        // The Formatter is chosen by the initial value.
        JFormattedTextField defaultDateField =
            new JFormattedTextField(new Date());

        // The Formatter is chosen by the given Format.
        JFormattedTextField noInitialValueField =
            new JFormattedTextField(DateFormat.getDateInstance());

        // Uses a custom DateFormat.
        DateFormat customFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        JFormattedTextField customFormatField =
            new JFormattedTextField(new DateFormatter(customFormat));

        // Uses a RelativeDateFormat.
        DateFormat relativeFormat = new RelativeDateFormat();
        JFormattedTextField relativeFormatField =
            new JFormattedTextField(new DateFormatter(relativeFormat));

        // Uses a custom DateFormatter that allows relative input and
        // prints natural language strings.
        JFormattedTextField relativeFormatterField =
            new JFormattedTextField(new RelativeDateFormatter());

        // Uses a custom FormatterFactory that used different formatters
        // for the display and while editing.
        DefaultFormatterFactory formatterFactory =
            new DefaultFormatterFactory(new RelativeDateFormatter(false, true),
                                        new RelativeDateFormatter(true, true));
        JFormattedTextField relativeFactoryField =
            new JFormattedTextField(formatterFactory);

        // Wraps a DateFormatter to map empty strings to null and vice versa.
        JFormattedTextField numberOrNullField =
            new JFormattedTextField(new EmptyDateFormatter());

        // Wraps a DateFormatter to map empty strings to -1 and vice versa.
        Date epoch = new Date(0); // January 1, 1970
        JFormattedTextField numberOrEmptyValueField =
            new JFormattedTextField(new EmptyDateFormatter(epoch));
        numberOrEmptyValueField.setValue(epoch);

        // Commits value on valid edit text
        DefaultFormatter formatter = new RelativeDateFormatter();
        formatter.setCommitsOnValidEdit(true);
        JFormattedTextField commitOnValidEditField =
            new JFormattedTextField(formatter);

        // A date field as created by the BasicComponentFactory:
        // Uses relative date input, and maps empty strings to null.
        ValueModel dateHolder = new ValueHolder();
        JFormattedTextField componentFactoryField =
            ExampleComponentFactory.createDateField(dateHolder);

        Format displayFormat = new DisplayFormat(DateFormat.getDateInstance());
        List<JFormattedTextField> fields = new LinkedList<JFormattedTextField>();
        fields.add(Utils.appendRow(builder, "Default:",               defaultDateField,        displayFormat));
        fields.add(Utils.appendRow(builder, "No initial value:",      noInitialValueField,     displayFormat));
        fields.add(Utils.appendRow(builder, "Empty <->  null:",       numberOrNullField,       displayFormat));
        fields.add(Utils.appendRow(builder, "Empty <-> epoch:",       numberOrEmptyValueField, displayFormat));
        fields.add(Utils.appendRow(builder, "Short format:",          customFormatField,       displayFormat));
        fields.add(Utils.appendRow(builder, "Relative format:",       relativeFormatField,     displayFormat));
        fields.add(Utils.appendRow(builder, "Relative formatter:",    relativeFormatterField,  displayFormat));
        fields.add(Utils.appendRow(builder, "Relative factory:",      relativeFactoryField,    displayFormat));
        fields.add(Utils.appendRow(builder, "Commits on valid edit:", commitOnValidEditField,  displayFormat));
        fields.add(Utils.appendRow(builder, "Relative, maps null:",   componentFactoryField,   displayFormat));

        return fields;
    }


}
