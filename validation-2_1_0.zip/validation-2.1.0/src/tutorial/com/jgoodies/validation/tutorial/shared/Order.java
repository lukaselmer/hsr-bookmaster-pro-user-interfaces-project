/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.shared;

import java.util.Date;

import com.jgoodies.binding.beans.Model;


/**
 * Describes an order that demonstrates different types of constraints.
 * The property constraints are: mandatory vs. optional,
 * minimum and maximum length, minimum and maximum values,
 * linked constraints.
 * Provides the following bound properties:
 * <em>orderNo, orderDate, deliveryDate, deliveryNotes</em>.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.11 $
 */
public class Order extends Model {

    // Names of the Bound Bean Properties *************************************

    public static final String PROPERTYNAME_DELIVERY_DATE  = "deliveryDate";
    public static final String PROPERTYNAME_DELIVERY_NOTES = "deliveryNotes";
    public static final String PROPERTYNAME_ORDER_DATE     = "orderDate";
    public static final String PROPERTYNAME_ORDER_NO       = "orderNo";


    // Constants **************************************************************

    /**
     * The time value used to map {@code null} dates.
     *
     * @see #getOrderDate()
     * @see #setOrderDate(Date)
     * @see #getDeliveryDate()
     * @see #setDeliveryDate(Date)
     */
    private static final long NO_DATE = -1;

    // Instance Fields ********************************************************

    /**
     * Holds a number that identifies the order.
     *
     * @see #getOrderNo()
     * @see #setOrderNo(String)
     *
     * validation-constraints:
     *     mandatory
     *     min-length:  5
     *     max-length: 10
     */
    private String orderNo;

    /**
     * Holds the date this order has been created.
     * Stores the Date's time to avoid external mutations.
     * -1 indicates no Date has been set.
     *
     * @see #getOrderDate()
     * @see #setOrderDate(Date)
     *
     * validation-constraints:
     *      linked: value <= valueOf(deliveryDate)
     */
    private long orderDate;

    /**
     * Holds the date where the goods are delivered.
     * Stores the Date's time to avoid external mutations.
     * -1 indicates no Date has been set.
     *
     * @see #getDeliveryDate()
     * @see #setDeliveryDate(Date)
     *
     * validation-constraints:
     *     mandatory
     *     linked: value >= valueOf(orderDate)
     */
    private long deliveryDate;


    /**
     * Holds optional notes for the delivery, packaging or shipment.
     *
     * @see #getDeliveryNotes()
     * @see #setDeliveryNotes(String)
     *
     * validation-constraints:
     *     maxLength(30)
     */
    private String deliveryNotes;


    // Instance Creation ******************************************************

    /**
     * Constructs an empty <code>Order</code>.
     */
    public Order() {
        orderDate = -1;
        deliveryDate = -1;
    }


    // Access to Bound Properties *********************************************


    /**
     * Returns this order's unique id.
     *
     * @return the order's no, a system wide unique id
     *
     * @see #setOrderNo(String)
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * Sets a new unique order number.
     *
     * @param newValue the order number to be set
     *
     * @see #getOrderNo()
     */
    public void setOrderNo(String newValue) {
        String oldValue = getOrderNo();
        orderNo = newValue;
        firePropertyChange(PROPERTYNAME_ORDER_NO, oldValue, newValue);
    }


    /**
     * Returns the date that describes when this order has been initiated
     * by the customer.
     *
     * @return the order date
     *
     * @see #setOrderDate(Date)
     */
    public Date getOrderDate() {
        return orderDate == NO_DATE
            ? null
            : new Date(orderDate);
    }

    /**
     * Sets this order's order date that describes when the order has
     * been initiated by the customer. Stores the new Date's time,
     * not the Date itself, to avoid external modifications.
     *
     * @param newDate   the order date to be set
     *
     * @see #getOrderDate()
     * @see #getDeliveryDate()
     */
    public void setOrderDate(Date newDate) {
        Date oldDate = getOrderDate();
        orderDate = newDate == null ? NO_DATE : newDate.getTime();
        firePropertyChange(PROPERTYNAME_ORDER_DATE, oldDate, newDate);
    }


    /**
     * Returns the date that describes when the product has been delivered.
     *
     * @return the delivery date
     *
     * @see #setDeliveryDate(Date)
     * @see #getOrderDate()
     */
    public Date getDeliveryDate() {
        return deliveryDate == NO_DATE
            ? null
            : new Date(deliveryDate);
    }

    /**
     * Sets this order's delivery date. Stores the new Date's time,
     * not the Date itself, to avoid external modifications.
     *
     * @param newDate  the delivery date to be set
     *
     * @see #getDeliveryDate()
     * @see #getOrderDate()
     */
    public void setDeliveryDate(Date newDate) {
        Date oldDate = getDeliveryDate();
        deliveryDate = newDate == null ? NO_DATE : newDate.getTime();
        firePropertyChange(PROPERTYNAME_DELIVERY_DATE, oldDate, newDate);
    }


    /**
     * Returns this order's optional delivery notes that describe
     * the delivery, packaging or shipment.
     *
     * @return the delivery notes
     *
     * @see #setDeliveryNotes(String)
     */
    public String getDeliveryNotes() {
        return deliveryNotes;
    }

    /**
     * Sets this order's optional delivery notes that describe
     * the delivery, packaging or shipment.
     *
     * @param newNotes  the delivery notes to be set
     *
     * @see #getDeliveryNotes()
     */
    public void setDeliveryNotes(String newNotes) {
        String oldNotes = getDeliveryNotes();
        deliveryNotes = newNotes;
        firePropertyChange(PROPERTYNAME_DELIVERY_NOTES, oldNotes, newNotes);
    }


}
