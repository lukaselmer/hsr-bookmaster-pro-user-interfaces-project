/*
 * Copyright (c) 2003-2009 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.validator;

import java.util.Date;

import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.tutorial.shared.Order;
import com.jgoodies.validation.tutorial.shared.OrderModel;
import com.jgoodies.validation.util.PropertyValidationSupport;
import com.jgoodies.validation.util.ValidationUtils;


/**
 * Validates an OrderModel.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.10 $
 */
public final class OrderModelValidator {

    /**
     * Provides the order models to be validated.
     */
    private final OrderModel orderModel;


    // Instance Creation ******************************************************

    /**
     * Constructs an OrderModelValidator on the given order model.
     *
     * @param orderModel   provides the order models to be validated
     */
    public OrderModelValidator(OrderModel orderModel) {
        this.orderModel = orderModel;
    }


    // Validation *************************************************************

    /**
     * Validates the order models and returns the result
     * as an instance of {@link ValidationResult}.
     *
     * @return the validation result
     */
    public ValidationResult validate() {
        String orderNo       = (String) orderModel.getModel(Order.PROPERTYNAME_ORDER_NO).getValue();
        Date orderDate       = (Date)   orderModel.getModel(Order.PROPERTYNAME_ORDER_DATE).getValue();
        Date deliveryDate    = (Date)   orderModel.getModel(Order.PROPERTYNAME_DELIVERY_DATE).getValue();
        String deliveryNotes = (String) orderModel.getModel(Order.PROPERTYNAME_DELIVERY_NOTES).getValue();

        PropertyValidationSupport support =
            new PropertyValidationSupport(orderModel, "Order");

        if (ValidationUtils.isBlank(orderNo))
            support.addError("Order No", "is mandatory");
        else if (!ValidationUtils.hasBoundedLength(orderNo, 5, 10))
            support.addError("Order No", "length must be in [5, 10]");

        if (orderDate == null)
            support.addError("Order Date", "is mandatory");

        if (orderDate != null
                && deliveryDate != null
                && orderDate.after(deliveryDate))
            support.addWarning("Delivery Date", "shall be after the order date");

        if (deliveryNotes != null
                && !ValidationUtils.hasMaximumLength(deliveryNotes, 30))
            support.addWarning("Notes", "length shall be in [0, 30]");

        return support.getResult();
       }


}
